# AI Study Companion

A root-free floating overlay app for Android. It floats a draggable bubble over any
app, captures a real-time screenshot of the current screen with `MediaProjection`,
extracts the visible text with Google ML Kit OCR, and sends that text (plus a smart
system prompt) to the OpenAI or Gemini API using **your own API key**.

The AI answers come back in super-simple Hinglish bullet points, shown in a
semi-transparent overlay card next to the floating menu.

## Features

- **First-launch setup screen** (`MainActivity`)
  - Save your OpenAI or Gemini API key locally via `SharedPreferences`.
  - Choose provider, model, and optional custom endpoint.
  - One-tap "Start / Stop Service" with guided permission flow:
    - Display over other apps (`Settings.ACTION_MANAGE_OVERLAY_PERMISSION`)
    - MediaProjection screen capture (consent dialog)
    - Notifications (Android 13+, needed for the foreground service)
  - The service only starts after both permissions are granted.
- **Floating dock** (`FloatingService`)
  - Minimized state: a small circular, draggable bubble.
  - Tap the bubble -> expand into a horizontal menu with 4 buttons:
    - Refresh - clears the OCR cache and hides the AI card.
    - Tips - runs capture + OCR + AI, the main intelligence trigger.
    - Minimize - back to the circular bubble.
    - Close - stops the foreground service and removes every overlay view.
  - Expanded/result windows use `WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY`
    with safe attach/detach handling (no `BadTokenException` crashes).
- **Live intelligence (Tips)**
  1. Grabs the latest frame from a persistent `ImageReader` fed by a
     `MediaProjection` `VirtualDisplay` (a single virtual display is reused, which
     also respects the Android 14 single-use `MediaProjection` rule).
  2. Runs Google ML Kit Text Recognition on the captured `Bitmap`.
  3. Builds a JSON request (OkHttp) containing the extracted text and the system
     instruction that asks for simple Hinglish bullet points under 10 words each.
  4. Shows the answer in a semi-transparent result card next to the menu.
- **Refresh & cleanup (Phase D)**
  - Hides the AI card instantly, flushes the old OCR string, and recycles the
    previous screenshot bitmaps to prevent memory leaks.

## Project structure

```
app/src/main/java/com/example/aistudycompanion/
├── MainActivity.kt        # Phase A: setup screen + permissions
├── FloatingService.kt     # Phases B, C, D: overlay UI, capture, OCR, AI flow
├── AiApiClient.kt         # OkHttp requests + response parsing (OpenAI & Gemini)
└── PrefsManager.kt        # SharedPreferences wrapper

app/src/main/res/layout/
├── activity_main.xml       # Setup screen
├── overlay_bubble.xml      # Circular draggable bubble
├── overlay_menu.xml        # 4-button floating menu
└── overlay_result_card.xml # AI result card
```

## Requirements

- Android Studio (Hedgehog or newer recommended)
- JDK 17
- Android SDK Platform 34
- Gradle 8.7 (the wrapper properties are included; Android Studio will fetch it)

## Build & run

1. Open the `AIStudyCompanion/` folder in Android Studio.
2. Let Gradle sync (this downloads AGP 8.5.2, ML Kit, OkHttp, etc.).
3. Run on a device or emulator running Android 8.0 (API 26) or higher.
4. In the app:
   - Enter your API key (OpenAI `sk-...` or Gemini `AIza...`).
   - Choose the provider/model and tap **Save Settings**.
   - Tap **Start Service** and grant both permissions when prompted.

> Generating the Gradle wrapper jar: if your IDE does not provide it, run
> `gradle wrapper --gradle-version 8.7` from a machine with Gradle installed,
> or let Android Studio create it automatically on first sync.

## Permissions

| Permission | Why |
| --- | --- |
| `SYSTEM_ALERT_WINDOW` | Draw the floating bubble / menu / result card |
| `FOREGROUND_SERVICE` | Keep the capture service alive |
| `FOREGROUND_SERVICE_MEDIA_PROJECTION` | Foreground service type for capture (API 34) |
| `POST_NOTIFICATIONS` | Show the service notification (API 33+) |

## Notes

- The API key is stored only on-device in `SharedPreferences` and is sent only to
  the endpoint you configured (OpenAI or Gemini) inside your own API call.
- On Android 14+ a fresh screen-capture consent dialog appears each time you start
  the service; this is enforced by the OS.
- The capture resolution is fixed to the display size at service start. Rotating
  the screen while the service is running is fine, but the next service restart
  re-reads the current size.
