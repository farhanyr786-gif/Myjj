# Keep ML Kit Text Recognition
-keep class com.google.mlkit.** { *; }
-keep class com.google.android.gms.mlkit.** { *; }

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
