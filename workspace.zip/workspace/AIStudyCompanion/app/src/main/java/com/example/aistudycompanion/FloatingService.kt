package com.example.aistudycompanion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizerOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class FloatingService : Service() {

    companion object {
        private const val TAG = "FloatingService"
        private const val CHANNEL_ID = "study_companion_channel"
        private const val NOTIFICATION_ID = 1
        private const val BUBBLE_SIZE_DP = 64
        private const val MENU_WIDTH_DP = 250
        private const val MENU_HEIGHT_DP = 84

        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
    }

    private val prefs by lazy { PrefsManager(this) }
    private val windowManager by lazy { getSystemService(Context.WINDOW_SERVICE) as WindowManager }
    private val mainHandler = Handler(Looper.getMainLooper())
    private val workExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    private val recognizer =
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var screenWidth = 0
    private var screenHeight = 0

    private var bubbleView: View? = null
    private var menuView: View? = null
    private var resultCard: View? = null
    private var resultLoading: ProgressBar? = null
    private var resultStatus: TextView? = null
    private var resultText: TextView? = null

    private var bubbleParams: WindowManager.LayoutParams? = null
    private var anchorX = 0
    private var anchorY = 0

    private var isExpanded = false
    private var isAiRunning = false
    private var isStopping = false

    @Suppress("unused")
    private var currentOcrText: String = ""
    private var lastFrame: Bitmap? = null

    private val touchSlop by lazy { ViewConfiguration.get(this).scaledTouchSlop }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode != -1 && resultData != null && projection == null) {
            setupProjection(resultCode, resultData)
        }

        if (projection != null && bubbleView == null) {
            showBubble()
        } else if (projection == null) {
            Log.w(TAG, "Projection not available yet")
        }

        prefs.serviceRunning = true
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        isStopping = true
        removeAllViews()
        releaseProjection()
        workExecutor.shutdownNow()
        prefs.serviceRunning = false
        super.onDestroy()
    }

    // ------------------------------------------------------------------ //
    // Foreground / notification
    // ------------------------------------------------------------------ //

    private fun createNotificationChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Study Companion",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Floating overlay service"
            setShowBadge(false)
        }
        nm.createNotificationChannel(channel)
    }

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("AI Study Companion")
            .setContentText("Floating assistant is active")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .build()
    }

    // ------------------------------------------------------------------ //
    // MediaProjection setup
    // ------------------------------------------------------------------ //

    private fun setupProjection(resultCode: Int, data: Intent) {
        try {
            val projectionManager =
                getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

            projection = projectionManager.getMediaProjection(resultCode, data)

            val metrics: DisplayMetrics = resources.displayMetrics
            screenWidth = metrics.widthPixels
            screenHeight = metrics.heightPixels

            imageReader = ImageReader.newInstance(
                screenWidth,
                screenHeight,
                PixelFormat.RGBA_8888,
                2
            )

            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    super.onStop()
                    mainHandler.post {
                        if (!isStopping) {
                            stopEverything("Screen capture was stopped by the system.")
                        }
                    }
                }
            }, mainHandler)

            virtualDisplay = projection?.createVirtualDisplay(
                "AIStudyCapture",
                screenWidth,
                screenHeight,
                metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                mainHandler
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set up projection", e)
            projection = null
            stopSelf()
        }
    }

    private fun releaseProjection() {
        try {
            virtualDisplay?.release()
        } catch (e: Exception) {
            Log.w(TAG, "release virtual display", e)
        }
        virtualDisplay = null

        try {
            imageReader?.close()
        } catch (e: Exception) {
            Log.w(TAG, "close image reader", e)
        }
        imageReader = null

        try {
            projection?.stop()
        } catch (e: Exception) {
            Log.w(TAG, "stop projection", e)
        }
        projection = null

        lastFrame?.let { recycleQuietly(it) }
        lastFrame = null
    }

    // ------------------------------------------------------------------ //
    // Window management (bubble / menu / result card)
    // ------------------------------------------------------------------ //

    private fun showBubble() {
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_bubble, null)
        val size = dp(BUBBLE_SIZE_DP)
        val params = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = anchorX.coerceIn(0, (screenWidth - size).coerceAtLeast(0))
            y = anchorY.coerceIn(0, (screenHeight - size).coerceAtLeast(0))
            setTitle("AIStudyBubble")
        }

        try {
            windowManager.addView(view, params)
        } catch (e: Exception) {
            Log.e(TAG, "addView bubble failed", e)
            return
        }

        bubbleView = view
        bubbleParams = params
        anchorX = params.x
        anchorY = params.y
        setupBubbleTouch(view, params)
    }

    private fun setupBubbleTouch(view: View, params: WindowManager.LayoutParams) {
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        var dragging = false

        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (Math.abs(dx) >= touchSlop || Math.abs(dy) >= touchSlop) {
                        dragging = true
                    }
                    if (dragging) {
                        params.x = (initialX + dx).coerceIn(0, (screenWidth - params.width).coerceAtLeast(0))
                        params.y = (initialY + dy).coerceIn(0, (screenHeight - params.height).coerceAtLeast(0))
                        anchorX = params.x
                        anchorY = params.y
                        try {
                            windowManager.updateViewLayout(view, params)
                        } catch (e: Exception) {
                            Log.w(TAG, "updateViewLayout bubble", e)
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) {
                        view.performClick()
                    }
                    true
                }
                else -> true
            }
        }

        view.setOnClickListener { expandMenu() }
    }

    private fun expandMenu() {
        if (isExpanded) return
        isExpanded = true
        hideBubble()
        showMenu()
    }

    private fun minimize() {
        hideResult()
        hideMenu()
        isExpanded = false
        showBubble()
    }

    private fun showMenu() {
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_menu, null)
        val width = dp(MENU_WIDTH_DP)
        val params = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = anchorX.coerceIn(0, (screenWidth - width).coerceAtLeast(0))
            y = anchorY.coerceIn(0, (screenHeight - dp(MENU_HEIGHT_DP)).coerceAtLeast(0))
            setTitle("AIStudyMenu")
        }

        try {
            windowManager.addView(view, params)
        } catch (e: Exception) {
            Log.e(TAG, "addView menu failed", e)
            return
        }

        menuView = view
        view.findViewById<View>(R.id.itemRefresh).setOnClickListener { onRefresh() }
        view.findViewById<View>(R.id.itemTips).setOnClickListener { onTips() }
        view.findViewById<View>(R.id.itemMinimize).setOnClickListener { minimize() }
        view.findViewById<View>(R.id.itemClose).setOnClickListener { stopEverything() }
    }

    private fun hideBubble() {
        removeViewSafe(bubbleView)
        bubbleView = null
        bubbleParams = null
    }

    private fun hideMenu() {
        removeViewSafe(menuView)
        menuView = null
    }

    private fun removeViewSafe(view: View?) {
        if (view == null) return
        try {
            if (view.isAttachedToWindow) {
                windowManager.removeView(view)
            }
        } catch (e: Exception) {
            Log.w(TAG, "removeView failed", e)
        }
    }

    private fun removeAllViews() {
        hideBubble()
        hideMenu()
        hideResult()
    }

    // ------------------------------------------------------------------ //
    // Result card
    // ------------------------------------------------------------------ //

    private fun ensureResultCard() {
        if (resultCard != null) return
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_result_card, null)
        resultCard = view
        resultLoading = view.findViewById(R.id.resultLoading)
        resultStatus = view.findViewById(R.id.resultStatus)
        resultText = view.findViewById(R.id.resultText)
        view.findViewById<View>(R.id.resultClose).setOnClickListener { hideResult() }

        val cardWidth = (screenWidth - dp(40)).coerceAtLeast(dp(240))
        val params = WindowManager.LayoutParams(
            cardWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(20)
            y = (anchorY + dp(MENU_HEIGHT_DP) + dp(8))
                .coerceAtMost((screenHeight - dp(140)).coerceAtLeast(dp(48)))
                .coerceAtLeast(dp(48))
            setTitle("AIStudyResult")
        }

        try {
            windowManager.addView(view, params)
        } catch (e: Exception) {
            Log.e(TAG, "addView result card failed", e)
            resultCard = null
        }
    }

    private fun showLoading(message: String) {
        ensureResultCard()
        resultCard?.let {
            resultLoading?.visibility = View.VISIBLE
            resultStatus?.visibility = View.VISIBLE
            resultText?.visibility = View.GONE
            resultStatus?.text = message
        }
    }

    private fun updateStatus(message: String) {
        resultStatus?.text = message
    }

    private fun showResult(text: String) {
        ensureResultCard()
        resultLoading?.visibility = View.GONE
        resultStatus?.visibility = View.GONE
        resultText?.visibility = View.VISIBLE
        resultText?.text = text
    }

    private fun hideResult() {
        removeViewSafe(resultCard)
        resultCard = null
        resultLoading = null
        resultStatus = null
        resultText = null
    }

    // ------------------------------------------------------------------ //
    // Phase D: Refresh
    // ------------------------------------------------------------------ //

    private fun onRefresh() {
        hideResult()
        currentOcrText = ""
        recycleQuietly(lastFrame)
        lastFrame = null
    }

    private fun recycleQuietly(bitmap: Bitmap?) {
        try {
            if (bitmap != null && !bitmap.isRecycled) {
                bitmap.recycle()
            }
        } catch (e: Exception) {
            Log.w(TAG, "recycle bitmap", e)
        }
    }

    // ------------------------------------------------------------------ //
    // Phase C: Tips workflow (capture -> OCR -> AI -> display)
    // ------------------------------------------------------------------ //

    private fun onTips() {
        if (isAiRunning) {
            updateStatus("Already working on it...")
            return
        }
        if (projection == null || imageReader == null) {
            showResult("Screen capture is not active. Restart the service from the app.")
            return
        }
        if (prefs.apiKey.isBlank()) {
            showResult("No API key set. Open the app and save your key first.")
            return
        }
        isAiRunning = true
        showLoading("Capturing screen...")

        workExecutor.execute {
            val bitmap = grabCurrentFrame()
            if (bitmap == null) {
                mainHandler.post {
                    isAiRunning = false
                    showResult("Could not capture the screen right now. Try again.")
                }
                return@execute
            }

            recycleQuietly(lastFrame)
            lastFrame = bitmap

            val input = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(input)
                .addOnSuccessListener { visionText ->
                    val text = visionText.text.trim()
                    currentOcrText = text
                    if (text.isEmpty()) {
                        recycleQuietly(bitmap)
                        lastFrame = null
                        mainHandler.post {
                            isAiRunning = false
                            showResult("No text detected on this screen.")
                        }
                        return@addOnSuccessListener
                    }

                    val wordCount = text.split("\\s+".toRegex()).size
                    mainHandler.post { updateStatus("Found $wordCount words. Asking AI...") }

                    workExecutor.execute {
                        try {
                            val answer = AiApiClient.call(prefs, text)
                            mainHandler.post {
                                recycleQuietly(bitmap)
                                lastFrame = null
                                isAiRunning = false
                                showResult(answer)
                            }
                        } catch (e: Exception) {
                            mainHandler.post {
                                recycleQuietly(bitmap)
                                lastFrame = null
                                isAiRunning = false
                                showResult("AI error: ${e.message}")
                            }
                        }
                    }
                }
                .addOnFailureListener { e ->
                    recycleQuietly(bitmap)
                    lastFrame = null
                    mainHandler.post {
                        isAiRunning = false
                        showResult("OCR failed: ${e.message}")
                    }
                }
        }
    }

    private fun grabCurrentFrame(): Bitmap? {
        val reader = imageReader ?: return null
        val image = try {
            reader.acquireLatestImage()
        } catch (e: Exception) {
            Log.w(TAG, "acquireLatestImage failed", e)
            null
        } ?: return null

        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val width = image.width
            val height = image.height
            val rowPadding = rowStride - pixelStride * width
            val paddedWidth = width + rowPadding / pixelStride

            val padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
            padded.copyPixelsFromBuffer(buffer)

            if (rowPadding > 0) {
                Bitmap.createBitmap(padded, 0, 0, width, height)
            } else {
                padded
            }
        } catch (e: Exception) {
            Log.w(TAG, "convert frame failed", e)
            null
        } finally {
            image.close()
        }
    }

    // ------------------------------------------------------------------ //
    // Close / cleanup
    // ------------------------------------------------------------------ //

    private fun stopEverything(reason: String? = null) {
        if (isStopping) return
        isStopping = true
        removeAllViews()
        releaseProjection()
        prefs.serviceRunning = false
        if (reason != null) {
            toast(reason)
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
