package com.example.aistudycompanion

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.aistudycompanion.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var mediaProjectionManager: MediaProjectionManager
    private val prefs by lazy { PrefsManager(this) }

    private val overlayPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            refreshUi()
            if (Settings.canDrawOverlays(this) && !prefs.serviceRunning) {
                requestProjectionPermission()
            }
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            requestProjectionPermission()
        }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                startFloatingService(result.resultCode, result.data)
            } else {
                toast("MediaProjection permission denied. Screen capture will not work.")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mediaProjectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        binding.providerGroup.setOnCheckedChangeListener { _, checkedId ->
            val isGemini = checkedId == R.id.radioGemini
            val current = binding.modelInput.text.toString()
            if (current.isBlank() || isGemini && current == "gpt-4o-mini" ||
                !isGemini && current == "gemini-1.5-flash"
            ) {
                binding.modelInput.setText(if (isGemini) "gemini-1.5-flash" else "gpt-4o-mini")
            }
        }

        binding.saveButton.setOnClickListener { saveSettings() }
        binding.startServiceButton.setOnClickListener { onStartServiceClicked() }

        loadSettings()
        refreshUi()
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    private fun loadSettings() {
        binding.apiKeyInput.setText(prefs.apiKey)
        binding.modelInput.setText(prefs.model.ifBlank { "gpt-4o-mini" })
        binding.endpointInput.setText(prefs.endpoint)
        if (prefs.provider == PrefsManager.PROVIDER_GEMINI) {
            binding.radioGemini.isChecked = true
        } else {
            binding.radioOpenAi.isChecked = true
        }
    }

    private fun saveSettings() {
        val key = binding.apiKeyInput.text.toString().trim()
        val model = binding.modelInput.text.toString().trim()
        val endpoint = binding.endpointInput.text.toString().trim()
        val provider =
            if (binding.radioGemini.isChecked) PrefsManager.PROVIDER_GEMINI else PrefsManager.PROVIDER_OPENAI

        prefs.apiKey = key
        prefs.model = model
        prefs.provider = provider
        prefs.endpoint = if (endpoint.isBlank()) {
            if (provider == PrefsManager.PROVIDER_GEMINI) {
                PrefsManager.DEFAULT_GEMINI_ENDPOINT
            } else {
                PrefsManager.DEFAULT_OPENAI_ENDPOINT
            }
        } else {
            endpoint
        }
        toast("Settings saved")
    }

    private fun onStartServiceClicked() {
        if (prefs.serviceRunning) {
            stopService(Intent(this, FloatingService::class.java))
            prefs.serviceRunning = false
            refreshUi()
            toast("Service stopped")
            return
        }

        if (binding.apiKeyInput.text.toString().trim().isEmpty()) {
            toast("Please enter your API key first.")
            return
        }
        saveSettings()

        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }
        requestProjectionPermission()
    }

    private fun requestOverlayPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        try {
            overlayPermissionLauncher.launch(intent)
        } catch (e: Exception) {
            toast("Could not open overlay settings")
        }
    }

    private fun requestProjectionPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        projectionLauncher.launch(mediaProjectionManager.createScreenCaptureIntent())
    }

    private fun startFloatingService(resultCode: Int, data: Intent) {
        val intent = Intent(this, FloatingService::class.java).apply {
            putExtra(FloatingService.EXTRA_RESULT_CODE, resultCode)
            putExtra(FloatingService.EXTRA_RESULT_DATA, data)
        }
        ContextCompat.startForegroundService(this, intent)
        prefs.serviceRunning = true
        refreshUi()
        toast("Service started")
    }

    private fun refreshUi() {
        val overlayGranted = Settings.canDrawOverlays(this)
        binding.startServiceButton.text =
            if (prefs.serviceRunning) "Stop Service" else "Start Service"

        binding.permissionStatus.text = buildString {
            append("Display over other apps: ")
            append(if (overlayGranted) "Granted" else "Not granted")
            append("\nScreen capture: ")
            append("Requested automatically on start")
            append("\nService state: ")
            append(if (prefs.serviceRunning) "Running" else "Stopped")
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
