package com.example.aistudycompanion

import java.io.IOException
import java.util.concurrent.TimeUnit
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

object AiApiClient {

    private const val SYSTEM_PROMPT =
        "Analyze this text from the user's screen. Detect the context (e.g., PDF book, code, chart). " +
            "Explain it in super simple Hinglish using short, punchy bullet points under 10 words each."

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    /** Blocks on the network call. Call from a background thread. */
    fun call(prefs: PrefsManager, screenText: String): String {
        require(prefs.apiKey.isNotBlank()) { "No API key configured." }

        val userText = "Text extracted from the user's current screen:\n\n$screenText"
        val provider = prefs.provider
        val endpoint = prefs.endpoint.ifBlank { prefs.defaultEndpoint() }

        val request = when (provider) {
            PrefsManager.PROVIDER_GEMINI ->
                buildGeminiRequest(endpoint, prefs.model, prefs.apiKey, userText)
            else ->
                buildOpenAiRequest(endpoint, prefs.model, prefs.apiKey, userText)
        }

        client.newCall(request).execute().use { response ->
            val body = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                throw IOException("HTTP ${response.code}: $body")
            }
            return when (provider) {
                PrefsManager.PROVIDER_GEMINI -> parseGemini(body)
                else -> parseOpenAi(body)
            }
        }
    }

    private fun buildOpenAiRequest(endpoint: String, model: String, key: String, userText: String): Request {
        val json = JSONObject().apply {
            put("model", model.ifBlank { "gpt-4o-mini" })
            put("temperature", 0.7)
            put(
                "messages",
                JSONArray().apply {
                    put(JSONObject().put("role", "system").put("content", SYSTEM_PROMPT))
                    put(JSONObject().put("role", "user").put("content", userText))
                }
            )
        }
        return Request.Builder()
            .url(endpoint)
            .header("Authorization", "Bearer $key")
            .header("Content-Type", "application/json")
            .post(json.toString().toRequestBody(jsonMediaType))
            .build()
    }

    private fun buildGeminiRequest(endpoint: String, model: String, key: String, userText: String): Request {
        var url = endpoint
        if (model.isNotBlank() && endpoint.endsWith(":generateContent") &&
            !endpoint.contains(model)
        ) {
            url = endpoint.replace(":generateContent", "/$model:generateContent")
        }
        if (!url.contains("key=")) {
            url += if (url.contains("?")) "&" else "?"
            url += "key=$key"
        }
        val json = JSONObject().apply {
            put(
                "contents",
                JSONArray().apply {
                    put(
                        JSONObject().apply {
                            put(
                                "parts",
                                JSONArray().apply { put(JSONObject().put("text", userText)) }
                            )
                        }
                    )
                }
            )
            put(
                "systemInstruction",
                JSONObject().apply {
                    put(
                        "parts",
                        JSONArray().apply { put(JSONObject().put("text", SYSTEM_PROMPT)) }
                    )
                }
            )
        }
        return Request.Builder()
            .url(url)
            .header("Content-Type", "application/json")
            .post(json.toString().toRequestBody(jsonMediaType))
            .build()
    }

    private fun parseOpenAi(body: String): String {
        val root = JSONObject(body)
        val choices = root.optJSONArray("choices") ?: throw IOException("Unexpected response: $body")
        if (choices.length() == 0) throw IOException("Empty choices: $body")
        val content = choices.getJSONObject(0)
            .optJSONObject("message")
            ?.optString("content", null)
        return content ?: throw IOException("Unexpected response: $body")
    }

    private fun parseGemini(body: String): String {
        val root = JSONObject(body)
        val candidates = root.optJSONArray("candidates")
            ?: throw IOException("Unexpected response: $body")
        if (candidates.length() == 0) {
            val msg = root.optJSONObject("promptFeedback")?.toString()
            throw IOException("No answer from Gemini${msg?.let { ": $it" } ?: ""}")
        }
        val parts = candidates.getJSONObject(0)
            .optJSONObject("content")
            ?.optJSONArray("parts")
            ?: throw IOException("Unexpected response: $body")
        val builder = StringBuilder()
        for (i in 0 until parts.length()) {
            builder.append(parts.getJSONObject(i).optString("text", ""))
            if (i < parts.length() - 1) builder.append("\n")
        }
        val text = builder.toString().trim()
        if (text.isEmpty()) throw IOException("Empty response from Gemini")
        return text
    }
}
